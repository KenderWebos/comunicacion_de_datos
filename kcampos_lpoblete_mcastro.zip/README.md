# comunicacion_de_datos

---

# Comunicarse con una planta

## Requisitos

- Tener instalado el IDE de Arduino
- Tener conectado el Arduino a la computadora
- Tener conectado los sensores al Arduino

## Instrucciones de compilación

1. Abrir arduino IDE
2. Cargar archivos
3. Cargar el programa
4. Conectar el arduino
5. Compilar el programa

## Videos

https://www.youtube.com/watch?v=f8V9zxCjCys

https://www.youtube.com/watch?v=Abhn0s5mJUk

> https://github.com/KenderWebos/comunicacion_de_datos
